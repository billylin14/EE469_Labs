# ARM Single Cycle CPU 64-bit

Built without RTL.
 
Billy Lin, Cameron Wutzke - Computer Architecture 1

## System Overview
A diagram for the basic CPU concept is below:
<p align="left">
  <img src="https://github.com/billylin14/EE469_Labs/blob/master/Lab3/Basic_CPU_Diagram.PNG" width="700" title="Basic CPU Diagram">
</p>

Our messy completed diagram:
<p align="left">
  <img src="https://github.com/billylin14/EE469_Labs/blob/master/Lab3/Final_CPU_Diagram.jpg" width="700" title="Final CPU Diagram">
</p>
